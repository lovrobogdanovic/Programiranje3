import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  Button,
  StyleSheet,
  TextInput,
  FlatList,
  ScrollView,
  TouchableOpacity
} from 'react-native';
import Ionicons from "@expo/vector-icons/Ionicons";

export function SettingsScreen({ route, navigation }) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [birthday, setBirthday] = useState('');
  const [gender, setGender] = useState('');
  const [phonenumber, setphonenumber] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const sendRequest = async () => {
    try {
      await fetch('https://webhook.site/c637ff9d-2768-4bcf-b706-2dbfce6bbc09', {
        method: 'post',
        mode: 'no-core',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          firstName: firstName,
          lastName: lastName,
          email: email,
          birthday: birthday,
          gender: gender,
          phonenumber: phonenumber,
          password: password,
          confirmPassword: confirmPassword,
        }),
      });
      setFirstName('');
      setLastName('');
      setEmail('');
      setBirthday('');
      setGender('');
      setUsername('');
      setPassword('');
      setConfirmPassword('');
    } catch (error) {}
  };

  function handleSettingsPress() {
    navigation.navigate('Settings');
  }

  return (
    <ScrollView style={styles.screen}>
      <View style={styles.wrap}>
        <View>
          <Text style={styles.title}>Sign up to continue</Text>
        </View>
        <View style={styles.inputWrapperOne}>
        <Text> first name </Text>
          <TextInput
            style={styles.input}
            onChangeText={setFirstName}
            value={firstName}
            placeholder="first name"
          />
          <Text>last name</Text>
          <TextInput
            style={styles.input}
            onChangeText={setLastName}
            value={lastName}
            placeholder="last name"
          />
        </View>
        <Text> email adress </Text>
        <View style={styles.inputWrapper}>
          <TextInput
            style={styles.input}
            onChangeText={setEmail}
            value={email}
            placeholder="email adress"
          />
        </View>



        <View style={styles.inputWrapper}>
          <Text> phone number </Text>
          <TextInput
            style={styles.input}
            onChangeText={setphonenumber}
            value={phonenumber}
            placeholder="phone number"
          />
        </View>

        <View style={styles.inputWrapper}>
          <Text> password </Text>
          <TextInput
            style={styles.input}
            onChangeText={setPassword}
            value={password}
            secureTextEntry={true}
            placeholder="password"
          />
        </View>

        <View style={styles.inputWrapper}>
          <Text> verify password </Text>
          <TextInput
            style={styles.input}
            onChangeText={setConfirmPassword}
            value={confirmPassword}
            secureTextEntry={true}
            placeholder="verify password"
          />
        </View>

        

        <TouchableOpacity onPress={sendRequest} style={styles.btn}>
        <Text style={styles.btnTxt}>Sign up</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    //alignItems: 'center',
    //justifyContent: "center",
    backgroundColor: '#fff',
    padding: 10,
    backgroundColor: 'purple',
    fontStyle: 'white',
  },
  inputWrapper: {
    //alignItems: 'center',
  },
  inputWrapperOne: {
    flexDirection: 'column',
  
  },
  wrap: {
    marginLeft: 10,
    marginRight: 10,
    padding: 5,
  },
  title: {
    fontSize: 20,
    fontFamily: '',
    fontWeight: "bold",
    backgroundColor: 'white',
    width: '80%',
  },

  btn: {
    borderWidth: 1.5,
    height: 45,
    backgroundColor: 'white',
  
  },
  btnTxt: {
    fontSize: 18,
    textAlign: "center",
    paddingTop: 10,
    fontFamily: 'Times New Roman',
    fontWeight: "bold",
    
  },
  input:{
    flex:1,
    borderWidth: 1,
    backgroundColor: '#fff',
    paddingLeft: 5,
    height: 45,
  }
});