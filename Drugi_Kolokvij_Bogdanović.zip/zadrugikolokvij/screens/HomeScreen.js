import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  Image,
  TouchableOpacity,
  ActivityIndicator,
  ScrollView,
} from 'react-native';

export function HomeScreen({ route, navigation }) {
  const [data, setData] = useState([]);
  const [isLoading, setLoading] = useState([]);

 function handleHomePress() {
    navigation.navigate('Home');
  }

 const getWines = async () => {
    try {
      const response = await fetch('https://makeup-api.herokuapp.com/api/v1/products.json?brand=maybelline');
      const json = await response.json();
      setData(json);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getWines();
  }, []);


   return (
    <ScrollView style={styles.container}>
      <View>
        {isLoading ? (
          <ActivityIndicator />
        ) : (
          <FlatList
            data={data}
            keyExtractor={({ id }, index) => id}
            renderItem={({ item }) => (
             <View style={styles.wrap}>
        <Image source={{ uri: `${item.image_link}` }} style={{ height: '100%', borderRadius: 20, width: '40%', resizeMode: "contain" }}/>
<View style={styles.text}>
        <Text> Marka: {item.brand}</Text>
        <Text> Naziv: {item.name}</Text>
        <Text> Vrsta proizvoda: {item.product_type}</Text>
        <Text> Cijena: {item.price}</Text>
        <Text> Opis: {item.description}</Text>
        <Text> Ocjena: {item.rating}</Text>
          </View>
          </View>
            )}
          />
        )}
      </View>
    </ScrollView>
  );
}




const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    flex: 1,
    backgroundColor: '#f5f5f5',
    paddingTop: 50,
    textAlign: 'center',
  },
wrap:{
  flexDirection: 'column',
    backgroundColor:'brown',
    borderRadius:20,
    margin: 10,
    padding: 10,
    alignContent: 'center',
    justifyContent: 'space-evenly'
},
text:{
descText: {
     flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
   fontSize: 12,
   borderRadius:20,
    margin: 10,
   alignItems: 'center',
    marginLeft: 30,

  },
}

});