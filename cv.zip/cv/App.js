import * as React from 'react';
import { Text, View, StyleSheet, Image, ImageBackground } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <ImageBackground
          style={styles.pozadina}
          source={{
            uri: 'https://www.maxpixel.net/static/photo/1x/Texture-Pattern-Cool-5943135.jpg',
          }}
        />

        <View style={styles.slikamene}>
          <Image
            style={styles.ja}
            source={{
              uri: 'https://media.tenor.com/d6e-Rvp97dEAAAAM/monkey-gangster-monkey.gif',
            }}
          />
        </View>

        <Text> Lovro Bogdanović </Text>
      </View>

      <View style={styles.body}>
        <ImageBackground
          style={styles.pozadinabody}
          source={{
            uri: 'https://www.maxpixel.net/static/photo/1x/Texture-Pattern-Cool-5943135.jpg',
          }}
        />
        <Text style={styles.h1}> Životopis </Text>
        <View style={styles.lista}>
          <View style={styles.obrazovanje}>
            <Text style={styles.boldano}> Obrazovanje: </Text>
            <Text> Filozofski fakultet Osijek </Text>
            <Text> Ekonomska škola Požega </Text>
          </View>
          <View style={styles.radnoiskustvo}>
            <Text style={styles.boldano}> Radno iskustvo: </Text>
            <Text> Sezonski konobar</Text>
            <Text> Content publishing specialist @ 57hours.com</Text>
          </View>
          <View style={styles.vjestine}>
          <Text style={styles.boldano}>Vještine: </Text>
          <Text> MS Office, timski igrač</Text>
          </View>
        </View>
      </View>

      <View style={styles.footer}>
        <ImageBackground
          style={styles.pozadina}
          source={{
            uri: 'https://www.maxpixel.net/static/photo/1x/Texture-Pattern-Cool-5943135.jpg',
          }}
        />
        <Text style={styles.copy}>Copyright Lovro Bogdanović</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
    position: 'relative',
    fontFamily: ''
  },
  header: {
    flex: 1,
    flexDirection: 'row',
    margin: 2,
    padding: 5,
  },
  body: {
    flex: 4,
    margin: 2,
    padding: 5,
  },
  footer: {
    flex: 1,
    margin: 2,
    padding: 5,
  },
  pozadina: {
    width: 300,
    height: 100,
    opacity: '10%',
    position: 'absolute',
  },
  pozadinabody: {
    width: 300,
    height: 400,
    opacity: '10%',
    position: 'absolute',
  },
  ja: {
    width: 100,
    height: 100,
    borderRadius: 10,
  },
  slikamene: {
    alignItems: 'right',
  },
  lista: {
    justifyContent: 'center',
    
  },
  obrazovanje: {
    padding: 5,
    
  },
  radnoiskustvo: {
    padding: 5,
  },
  boldano: {
    fontWeight: 'bold',
    textDecorationLine: 'underline',
    fontSize: 20,
  },
  vjestine:{
    padding: 5,
  },
  h1:{
    alignSelf: 'center',
    fontWeight: 'bold',
    fontSize: 40,
  },

  copy:{
    fontSize: 10,
    fontWeight: 'bold',
    
  },
});
