import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My first RN app </Text>
      </View>

      <View style={styles.jumbotron}>
        <View style={styles.left}>
          <Text>Lefty</Text>
        </View>

        <View style={styles.right}>
          <Text>Righty</Text>
        </View>
      </View>

      <Button title="klikni me" onPress={() => alert.alert('Button pressed')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
    margin: 5,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  header:{
flex: 1,
alignSelf: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    fontFamily: 'Helvetica',
  },

  jumbotron: {
    flexDirection: 'row',
    flex: 3,
    alignSelf: 'center',
  },

  left: {
    backgroundColor: 'grey',
    margin: 10,
    padding: 10,
    borderWidth: 5,
    borderRadius: 5,
    
  },

  right: {
    backgroundColor: 'grey',
    margin: 10,
    padding: 10,
    borderWidth: 5,
    borderRadius: 5,
    
  },
});
