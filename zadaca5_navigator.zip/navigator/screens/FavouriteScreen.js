import * as React from 'react';
import { Text, View, StyleSheet, Button, Image } from 'react-native';

export function FavouriteScreen({ route, navigation }) {
  function handleHomePress() {
    navigation.navigate('Home');
  }
  function handleSettingsPress() {
    navigation.navigate('Settings');
  }
  function handleProfilePress() {
    navigation.navigate('Profile');
  }

  return (
    <View style={styles.screen}>
      <Text>Favourite SCREEN</Text>
      <View style={styles.button1}>
        <Button
          title="GO TO THE SETTINGS SCREEN"
          onPress={handleSettingsPress}
        />
      </View>

      <View style={styles.button2}>
        <Button title="GO TO THE HOME SCREEN" onPress={handleHomePress} />
      </View>

      <View style={styles.button3}>
        <Button title="GO TO THE PROFILE SCREEN" onPress={handleProfilePress} />
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  screen: {
    flex: 1,
    padding: 30,
    alignContent: 'center',
    justifyContent: 'center',
  },

  button1: {
    padding: 5,
  },
  button2: {
    padding: 5,
  },
  button3: {
    padding: 5,
  },
});
