import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';

export function SettingsScreen({ route, navigation }) {
  function handleHomePress() {
    navigation.navigate('Home');
  }
  function handleProfilePress() {
    navigation.navigate('Profile');
  }

  function handleFavouritePress() {
    navigation.navigate('Favourite');
  }

  return (
    <View style={styles.screen}>
      <Text>SETTING SCREEN</Text>
      <View style={styles.button1}>
        <Button title="GO TO THE HOME SCREEN" onPress={handleHomePress} />
      </View>

      <View style={styles.button2}>
        <Button title="GO TO THE Profile SCREEN" onPress={handleProfilePress} />
      </View>

      <View style={styles.button3}>
        <Button
          title="GO TO THE FAVOURITE SCREEN"
          onPress={handleFavouritePress}
        />
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  screen: {
    flex: 1,
    alignContent: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  button1:{
    padding: 5, 
  },
  button2:{
    padding: 5,
  },
  button3:{
    padding: 5,
  },
});
