import * as React from 'react';
import { Text, View, StyleSheet, Button, Image } from 'react-native';

export function ProfileScreen({ route, navigation }) {
  function handleHomePress() {
    navigation.navigate('Home');
  }
  function handleSettingsPress() {
    navigation.navigate('Settings');
  }

  function handleFavouritePress() {
    navigation.navigate('Favourite');
  }

  return (
    <View style={styles.screen}>
      <Text>PROFILE SCREEN</Text>
      <View style={styles.button1}>
        <Text>
          <Button
            title="GO TO THE SETTINGS SCREEN"
            onPress={handleSettingsPress}
          />
        </Text>
      </View>

      <View style={styles.button2}>
        <Button title="GO TO THE HOME SCREEN" onPress={handleHomePress} />
      </View>

      <View style={styles.button3}>
        <Button
          title="GO TO THE FAVOURITE SCREEN"
          onPress={handleFavouritePress}
        />
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  screen: {
    flex: 1,
    padding: 30,
    alignContent: 'center',
    justifyContent: 'center',
  },
  button1: {
    padding: 5,
  },
  button2: {
    padding: 5,
  },
  button3: {
    padding: 5,
  },
});
